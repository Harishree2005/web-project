#include <iostream>

int countSetBits(int num) {
    int count = 0;
    while (num) {
        count += num & 1;
        num >>= 1;
    }
    return count;
}

bool checkParity(int num) {
    int setBitsCount = countSetBits(num);
    return setBitsCount % 2 == 0;
}

int main() {
    int num;
    std::cout << "Enter an integer: ";
    std::cin >> num;
    bool isEvenParity = checkParity(num);
    
    if (isEvenParity) {
        std::cout << "Number of set bits is even. Parity: EVEN\n";
    } else {
        std::cout << "Number of set bits is odd. Parity: ODD\n";
    }
    
    return 0;
}